document.getElementById('jokeBtn').addEventListener('click', generateJoke);

function generateJoke() {
    fetch('https://official-joke-api.appspot.com/random_joke')
        .then(response => response.json())
        .then(data => {
            document.getElementById('joke').textContent = `${data.setup} - ${data.punchline}`;
        })
        .catch(error => {
            document.getElementById('joke').textContent = 'Oops! Something went wrong. Please try again later.';
            console.error('Error fetching joke:', error);
        });
}